caffeshop package
=================

Submodules
----------

caffeshop.asgi module
---------------------

.. automodule:: caffeshop.asgi
   :members:
   :undoc-members:
   :show-inheritance:

caffeshop.settings module
-------------------------

.. automodule:: caffeshop.settings
   :members:
   :undoc-members:
   :show-inheritance:

caffeshop.urls module
---------------------

.. automodule:: caffeshop.urls
   :members:
   :undoc-members:
   :show-inheritance:

caffeshop.wsgi module
---------------------

.. automodule:: caffeshop.wsgi
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: caffeshop
   :members:
   :undoc-members:
   :show-inheritance:
