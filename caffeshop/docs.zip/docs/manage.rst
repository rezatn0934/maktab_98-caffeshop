manage module
=============

.. automodule:: manage
   :members:
   :undoc-members:
   :show-inheritance:
