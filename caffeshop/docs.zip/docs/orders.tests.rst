orders.tests package
====================

Submodules
----------

orders.tests.test\_admin module
-------------------------------

.. automodule:: orders.tests.test_admin
   :members:
   :undoc-members:
   :show-inheritance:

orders.tests.test\_cart module
------------------------------

.. automodule:: orders.tests.test_cart
   :members:
   :undoc-members:
   :show-inheritance:

orders.tests.test\_models module
--------------------------------

.. automodule:: orders.tests.test_models
   :members:
   :undoc-members:
   :show-inheritance:

orders.tests.test\_urls module
------------------------------

.. automodule:: orders.tests.test_urls
   :members:
   :undoc-members:
   :show-inheritance:

orders.tests.test\_views module
-------------------------------

.. automodule:: orders.tests.test_views
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: orders.tests
   :members:
   :undoc-members:
   :show-inheritance:
