caffeshop
=========

.. toctree::
   :maxdepth: 4

   accounts
   caffeshop
   home
   manage
   menu
   orders
   test_utils
   utils
