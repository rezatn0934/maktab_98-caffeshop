accounts package
================

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   accounts.migrations
   accounts.templatetags
   accounts.tests

Submodules
----------

accounts.admin module
---------------------

.. automodule:: accounts.admin
   :members:
   :undoc-members:
   :show-inheritance:

accounts.apps module
--------------------

.. automodule:: accounts.apps
   :members:
   :undoc-members:
   :show-inheritance:

accounts.authentication module
------------------------------

.. automodule:: accounts.authentication
   :members:
   :undoc-members:
   :show-inheritance:

accounts.form module
--------------------

.. automodule:: accounts.form
   :members:
   :undoc-members:
   :show-inheritance:

accounts.manager module
-----------------------

.. automodule:: accounts.manager
   :members:
   :undoc-members:
   :show-inheritance:

accounts.mixins module
----------------------

.. automodule:: accounts.mixins
   :members:
   :undoc-members:
   :show-inheritance:

accounts.models module
----------------------

.. automodule:: accounts.models
   :members:
   :undoc-members:
   :show-inheritance:

accounts.urls module
--------------------

.. automodule:: accounts.urls
   :members:
   :undoc-members:
   :show-inheritance:

accounts.views module
---------------------

.. automodule:: accounts.views
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: accounts
   :members:
   :undoc-members:
   :show-inheritance:
