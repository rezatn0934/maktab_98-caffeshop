menu.migrations package
=======================

Submodules
----------

menu.migrations.0001\_initial module
------------------------------------

.. automodule:: menu.migrations.0001_initial
   :members:
   :undoc-members:
   :show-inheritance:

menu.migrations.0002\_alter\_product\_options module
----------------------------------------------------

.. automodule:: menu.migrations.0002_alter_product_options
   :members:
   :undoc-members:
   :show-inheritance:

menu.migrations.0003\_name\_of\_extension module
------------------------------------------------

.. automodule:: menu.migrations.0003_name_of_extension
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: menu.migrations
   :members:
   :undoc-members:
   :show-inheritance:
