accounts.templatetags package
=============================

Submodules
----------

accounts.templatetags.user\_tag module
--------------------------------------

.. automodule:: accounts.templatetags.user_tag
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: accounts.templatetags
   :members:
   :undoc-members:
   :show-inheritance:
