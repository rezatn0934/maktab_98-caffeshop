menu package
============

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   menu.migrations
   menu.tests

Submodules
----------

menu.admin module
-----------------

.. automodule:: menu.admin
   :members:
   :undoc-members:
   :show-inheritance:

menu.apps module
----------------

.. automodule:: menu.apps
   :members:
   :undoc-members:
   :show-inheritance:

menu.models module
------------------

.. automodule:: menu.models
   :members:
   :undoc-members:
   :show-inheritance:

menu.urls module
----------------

.. automodule:: menu.urls
   :members:
   :undoc-members:
   :show-inheritance:

menu.views module
-----------------

.. automodule:: menu.views
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: menu
   :members:
   :undoc-members:
   :show-inheritance:
