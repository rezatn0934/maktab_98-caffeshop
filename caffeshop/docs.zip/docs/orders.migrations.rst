orders.migrations package
=========================

Submodules
----------

orders.migrations.0001\_initial module
--------------------------------------

.. automodule:: orders.migrations.0001_initial
   :members:
   :undoc-members:
   :show-inheritance:

orders.migrations.0002\_alter\_order\_options module
----------------------------------------------------

.. automodule:: orders.migrations.0002_alter_order_options
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: orders.migrations
   :members:
   :undoc-members:
   :show-inheritance:
