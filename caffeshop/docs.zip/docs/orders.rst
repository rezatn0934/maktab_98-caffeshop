orders package
==============

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   orders.migrations
   orders.tests

Submodules
----------

orders.admin module
-------------------

.. automodule:: orders.admin
   :members:
   :undoc-members:
   :show-inheritance:

orders.apps module
------------------

.. automodule:: orders.apps
   :members:
   :undoc-members:
   :show-inheritance:

orders.cart module
------------------

.. automodule:: orders.cart
   :members:
   :undoc-members:
   :show-inheritance:

orders.forms module
-------------------

.. automodule:: orders.forms
   :members:
   :undoc-members:
   :show-inheritance:

orders.models module
--------------------

.. automodule:: orders.models
   :members:
   :undoc-members:
   :show-inheritance:

orders.urls module
------------------

.. automodule:: orders.urls
   :members:
   :undoc-members:
   :show-inheritance:

orders.views module
-------------------

.. automodule:: orders.views
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: orders
   :members:
   :undoc-members:
   :show-inheritance:
