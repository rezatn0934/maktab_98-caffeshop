menu.tests package
==================

Submodules
----------

menu.tests.test\_admin module
-----------------------------

.. automodule:: menu.tests.test_admin
   :members:
   :undoc-members:
   :show-inheritance:

menu.tests.test\_models module
------------------------------

.. automodule:: menu.tests.test_models
   :members:
   :undoc-members:
   :show-inheritance:

menu.tests.test\_urls module
----------------------------

.. automodule:: menu.tests.test_urls
   :members:
   :undoc-members:
   :show-inheritance:

menu.tests.test\_views module
-----------------------------

.. automodule:: menu.tests.test_views
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: menu.tests
   :members:
   :undoc-members:
   :show-inheritance:
